# Projeto do Curso de Otimização de Performance Web do Alura

Clone o projeto e faça `npm install` para instalar as dependências.
